#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
@Version: 1.0.0
@Project: Secure-Multi-Party-Computation-Protocol
@Author: Zhan Shi
@Time  : 2022/5/5 12:13
@File: __init__.py
@License: MIT
"""
__name__ = 'test_case'
